<?php
return array(
	//'配置项'=>'配置值'
    //'API_HOST' => 'http://cs.ao98.com',
    //'API_HOST' => '127.0.0.1:15510',
    'API_HOST' => 'http://htt.9zsq.xyz',
    'HOST_NAME' => 'http://htt.9zsq.xyz',
);